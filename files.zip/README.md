# Mazul App — Guía de instalación

## 1. Crear cuenta en Supabase (gratis)
Ve a https://supabase.com → New project → llamarlo "mazul"

## 2. Correr el schema
Dashboard → SQL Editor → pegar el contenido de `supabase_schema.sql` → Run

## 3. Crear el primer usuario (dueño)
Dashboard → Authentication → Users → Invite user
Después en SQL Editor:
```sql
INSERT INTO profiles (id, nombre, rol)
VALUES ('<uid del usuario creado>', 'Tu nombre', 'dueno');
```

## 4. Configurar variables de entorno
```bash
cp .env.example .env.local
# Editar .env.local con tus credenciales de Supabase
# Dashboard → Settings → API
```

## 5. Instalar y correr
```bash
npm install
npm run dev
```
Abre http://localhost:5173

## 6. Deploy en Vercel (gratis)
1. Sube el código a GitHub
2. Ve a https://vercel.com → Import project → selecciona el repo
3. Agrega las variables de entorno (VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY)
4. Deploy → obtienes URL tipo `mazul-app.vercel.app`
5. Comparte esa URL por WhatsApp con el equipo

## Módulos listos
- ✅ Auth con roles (dueño / encargado / mesero)
- ✅ Menú con costeos
- ✅ Cuentas por villa / externos
- ✅ Caja del día
- ✅ Reportes (solo dueño)
- ✅ PWA instalable desde el celular

## Próximos módulos
- Flujo completo de cargo (selección de platillos)
- Cierre y cobro de cuenta
- Inventario y compras
- Alertas de stock bajo
